package problems;

public class testes {
    public static void main(String[] args) {
        int[] array = new int[] {9, 10, 6, 7, 8};
        int retultado = findRotations(array);
        System.out.println(retultado);
    }
    
    public static int findRotations(int[] array){
        if (array != null)
            return binarySearchRotation(array, 0, array.length-1);
        
        return 0;
    }   


//TODO implement your code here
// throw new UnsupportedOperationException("Not implemented yet!");


public static int binarySearchRotation(int[] array, int left, int right) {
int rotation = 0;
int indiceControle = 0;
if (left < right) {
    int meio = (left + right) /2;
     // 9, 5, 6, 7, 8
    if (array[meio] < array[meio+1]) {
        binarySearchRotation(array, meio, right);
        if (array[meio] > array[meio +1]) {
            binarySearchRotation(array, left, meio-1);
        }
    }
    rotation +=1;    
}
return rotation;
} 
}

