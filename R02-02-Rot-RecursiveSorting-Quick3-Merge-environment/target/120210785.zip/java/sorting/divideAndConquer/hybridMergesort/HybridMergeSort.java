package sorting.divideAndConquer.hybridMergesort;

import java.util.Arrays;

import sorting.AbstractSorting;

/**
 * A classe HybridMergeSort representa a implementação de uma variação do
 * MergeSort que pode fazer uso do InsertionSort (um algoritmo híbrido) da
 * seguinte forma: o MergeSort é aplicado a entradas maiores a um determinado
 * limite. Caso a entrada tenha tamanho menor ou igual ao limite o algoritmo usa
 * o InsertionSort.
 * 
 * A implementação híbrida deve considerar os seguintes detalhes:
 * - Ter contadores das quantidades de MergeSorts e InsertionSorts aplicados, de forma
 *   que essa informação possa ser capturada pelo teste.
 * - A cada chamado do método de sort(T[] array) esses contadores são resetados. E a cada chamada
 *   interna de um merge ou insertion, os contadores MERGESORT_APPLICATIONS e
 *   INSERTIONSORT_APPLICATIONS são incrementados.
 * - O InsertionSort utilizado no algoritmo híbrido deve ser in-place.
 */
public class HybridMergeSort<T extends Comparable<T>> extends 
	AbstractSorting<T> {

    public static final int SIZE_LIMIT = 4;

    protected static int MERGESORT_APPLICATIONS = 0;
    protected static int INSERTIONSORT_APPLICATIONS = 0;

    @Override
    public void sort(T[] array, int leftIndex, int rightIndex) {
        MERGESORT_APPLICATIONS = 0;
        INSERTIONSORT_APPLICATIONS = 0;
        hybridMergeSort(array, leftIndex, rightIndex);
    }

    private void hybridMergeSort(T[] array, int leftIndex, int rightIndex) {
        if (rightIndex - leftIndex + 1 <= SIZE_LIMIT) {
            insertionSort(array, leftIndex, rightIndex);
            INSERTIONSORT_APPLICATIONS++;
        } else {
            int middleIndex = (leftIndex + rightIndex) / 2;
            hybridMergeSort(array, leftIndex, middleIndex);
            hybridMergeSort(array, middleIndex + 1, rightIndex);
            merge(array, leftIndex, middleIndex, rightIndex);
            MERGESORT_APPLICATIONS++;
        }
    }

    private void merge(T[] array, int leftIndex, int middleIndex, int rightIndex) {
        int n1 = middleIndex - leftIndex + 1;
        int n2 = rightIndex - middleIndex;

        T[] leftArray = Arrays.copyOfRange(array, leftIndex, leftIndex + n1);
        T[] rightArray = Arrays.copyOfRange(array, middleIndex + 1, middleIndex + 1 + n2);

        int i = 0;
        int j = 0;
        int k = leftIndex;

        while (i < n1 && j < n2) {
            if (leftArray[i].compareTo(rightArray[j]) <= 0) {
                array[k++] = leftArray[i++];
            } else {
                array[k++] = rightArray[j++];
            }
        }

        while (i < n1) {
            array[k++] = leftArray[i++];
        }

        while (j < n2) {
            array[k++] = rightArray[j++];
        }
    }

    private void insertionSort(T[] array, int leftIndex, int rightIndex) {
        for (int i = leftIndex + 1; i <= rightIndex; i++) {
            T key = array[i];
            int j = i - 1;

            while (j >= leftIndex && array[j].compareTo(key) > 0) {
                array[j + 1] = array[j];
                j--;
            }

            array[j + 1] = key;
        }
    }

}

